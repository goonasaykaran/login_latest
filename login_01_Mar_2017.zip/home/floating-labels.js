$(function() {
							$("body")
								.on("input propertychange", ".floating-label-form-group", function(e) {
									$(this).toggleClass("floating-label-form-group-with-value", !!$(e.target).val());
								})
								.on("focus", ".floating-label-form-group", function() {
									$(this).addClass("floating-label-form-group-with-focus");
								})
								.on("blur", ".floating-label-form-group", function() {
									$(this).removeClass("floating-label-form-group-with-focus");
								});
						});


$(document).on('click', '.panel-heading span.clickable', function(e){
    var $this = $(this);
	if(!$this.hasClass('panel-collapsed')) {
		$this.parents('.panel').find('.panel-body').slideUp();
		$this.addClass('panel-collapsed');
		$this.find('i').removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down');
	} else {
		$this.parents('.panel').find('.panel-body').slideDown();
		$this.removeClass('panel-collapsed');
		$this.find('i').removeClass('glyphicon-chevron-down').addClass('glyphicon-chevron-up');
	}
});



$(window).on("load resize ", function() {
  var scrollWidth = $('.tbl-content').width() - $('.tbl-content table').width();
  $('.tbl-header').css({'padding-right':scrollWidth});
}).resize();


$('#datetimepicker1 input').click(function(event){
   $('#datetimepicker1 ').data("DateTimePicker").show();
});

